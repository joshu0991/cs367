#define ASSIGN 31 
#define PLUS 27
#define PRINT 28
#define EOLN 29
#define FLOAT 30
#define MULT 32
