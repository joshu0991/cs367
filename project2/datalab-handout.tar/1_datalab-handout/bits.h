
unsigned float_abs(unsigned);
unsigned test_float_abs(unsigned);
int addOK(int, int);
int test_addOK(int, int);
int allEvenBits();
int test_allEvenBits();
int isNegative(int);
int test_isNegative(int);
int bitAnd(int, int);
int test_bitAnd(int, int);
